# Safety Management Solutions — UI/UX & Frontend Audit

**Scope:** Public-source review of the GitHub `main` branch on 20 October 2026. This is a code-level audit, not a claim that all pages passed browser testing.

## Executive summary

The existing direction is coherent and worth keeping: navy/sky/orange palette tokens, max-width containers, Tailwind responsive grids, visible `:focus-visible` styling, reduced-motion CSS, a skip link, lazy-loaded secondary pages, semantic form labels, and a fallback for contact enquiries are already present.

The highest-priority risks are not arbitrary spacing problems. They are a production asset-path issue, an unconfigured contact-form endpoint, and a desktop navigation breakpoint that can become cramped before the layout switches to its mobile menu.

## Findings by priority

### P0 — likely production defect: source-image URLs are hard-coded

`src/pages/HomePage.tsx` points five images to absolute paths under `/src/assets/images/...`. Vite normally rewrites imported source assets to hashed build URLs; a literal `/src/...` URL is not automatically rewritten and is likely to work in development but fail after a production build. This affects the hero photograph and the four service-card photographs.

**Fix:** import each image from `src/assets/images` and use the imported module in `src` props. The included patch does this without changing the design or image dimensions.

### P0 — inquiry form cannot submit until configured

`src/config/siteConfig.ts` still contains `YOUR_WEB3FORMS_ACCESS_KEY_HERE`. `ContactForm.tsx` checks for that placeholder and intentionally skips network submission, showing a configuration warning and a WhatsApp/call fallback instead. This is safer than a fake success state, but the primary online inquiry flow is not production-ready until a valid key is configured and tested.

**Fix:** configure the intended Web3Forms access key for production, then test both success and failure states. Do not paste a real key into public chat or commit private credentials. The form’s WhatsApp fallback should remain available.

### P1 — desktop nav can be too dense around laptop/tablet widths

`Header.tsx` turns on the seven-link desktop nav at Tailwind `lg` (1024px), while also rendering the wordmark, a quote CTA, `gap-8` around zones, and `gap-6` between links. That leaves a narrow range where the layout can feel cramped or force horizontal pressure. The patch moves the desktop-nav switch to `xl`, keeping the existing drawer for widths below 1280px.

### P1 — mobile menu is exposed as a modal without full keyboard-dialog behavior

The mobile drawer has `role="dialog"` and `aria-modal="true"`, and it locks body scrolling, but the inspected code does not add Escape-to-close, focus trapping, or focus restoration to the menu toggle. The patch adds Escape-to-close and an `aria-controls` relationship. Before calling the drawer fully accessible, also implement focus entry/trapping/restoration and confirm that focus cannot move to obscured page content while it is open.

### P1 — unknown paths silently resolve to the homepage

`src/utils/router.ts` normalizes unrecognized paths to `/`, while `App.tsx` has a `NotFoundPage` branch for an unknown route. With the current normalizer, that branch is effectively unreachable for ordinary unknown paths. Consider preserving an unmatched route (or using a dedicated not-found sentinel) so a typo or stale URL gets a genuine 404/not-found experience rather than silently displaying Home.

### P1 — unfinished business-hours placeholder is user-visible

`siteContent.contact.businessHoursPlaceholder` is `[confirm: operating business hours]`, and `ContactPage.tsx` renders that value directly in the “Consultation Hours” area. Replace it with confirmed opening hours or hide that row until the real value is supplied. Do not invent hours.

### P2 — form validation feedback needs stronger assistive-technology wiring

The contact form has labels, required fields, and visible error text, which is a good base. The inspected code does not use `aria-invalid`, `aria-describedby`, or a live region for field and submit-status feedback. Add stable IDs to each error message; bind each input to its error with `aria-describedby`; toggle `aria-invalid`; and announce success/configuration/failure messages with an appropriate live region.

### P2 — the “Office Location Map” is a visual placeholder, not an embedded map

The contact page draws a stylized grid and pin and provides an “Open in Google Maps” link. The external link is useful, but the section is not an actual map embed. Either label it as a location preview or embed a real map with a responsive aspect ratio and an accessible title, considering third-party privacy and loading cost.

### P2 — reduced-motion handling should be verified against all scripted scrolling

`App.tsx` avoids initializing Lenis when `prefers-reduced-motion: reduce` is active, and the CSS reduces animation durations. However, route navigation and the homepage step navigator explicitly call `window.scrollTo({ behavior: 'smooth' })`. Route these through a helper that uses `behavior: 'auto'` when reduced motion is requested.

## Existing strengths to preserve

- Design tokens are centralized in `src/index.css`.
- A keyboard-visible focus ring and skip link exist.
- Secondary pages are lazy-loaded with a loading fallback.
- Form controls have visible, correctly associated labels.
- The contact form avoids reporting false success and provides direct-contact fallback actions.
- The homepage uses consistent `max-w-7xl` containers and responsive grid classes.

## Verification matrix

| Area | Result from source review | What remains to verify in a real browser/build |
|---|---|---|
| Layout and spacing | Containers and many section paddings are consistent; no source-only proof of accidental negative-margin hacks found in inspected files | Render at 360×800, 390×844, 768×1024, 1024×768, 1280×800, and 1440×900; check horizontal scroll and footer/action-bar overlap |
| Above-the-fold | Hero starts directly after sticky header; large display type and feature card intentionally make the top section tall | Confirm first fold visually on mobile and laptop after the image path fix |
| Responsive navigation | 1024px `lg` breakpoint is likely tight for seven links plus CTA | Check tablet/laptop breakpoints; patch moves switch to `xl` |
| Links and routing | Navigation uses client-side `pushState` and handles `popstate`; unknown route fallback issue found | Click every route, refresh each direct route, test back/forward and invalid URL |
| Forms | Validation and honest error/configuration states exist; production key is placeholder | Configure endpoint and perform real test submission; test keyboard and screen reader announcements |
| Accessibility | Skip link, focus-visible rule and labels exist | Complete modal focus management; field error associations/live announcements; contrast audit on rendered states |
| Images/performance | Fixed-height image carriers reduce some layout-shift risk; literal source paths are a build risk | Run production build, inspect image requests, check dimensions/compression and Lighthouse LCP/CLS |
| SEO | `index.html` contains title, description, canonical, Open Graph, Twitter and LocalBusiness JSON-LD; router updates title/meta for client-side navigation | Verify generated per-route HTML has unique metadata/canonical, validate JSON-LD and sitemap/robots, test deployed status codes |
| Runtime quality | Static review only | `npm run lint`, `npm run build`, browser console, broken-link scan, and mobile/desktop screenshots were not run here |

## Recommended next steps

1. Apply `targeted-fixes.patch` and check that all five image files exist at the specified paths.
2. Configure the contact endpoint and replace the public hours placeholder with verified content (or remove the row).
3. Complete mobile-dialog focus management and form error announcements.
4. Run `npm run lint` and `npm run build`; then test all listed viewport sizes and direct page refreshes on the deployment host.
