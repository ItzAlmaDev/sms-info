Files in this bundle:
- website-audit.md: prioritized source-level audit with verified findings and remaining browser checks.
- targeted-fixes.patch: small proposed source patch for Vite image imports, safer responsive nav breakpoint, Escape-to-close, and aria-controls.

Important: the patch has not been applied to the GitHub repository or verified by a local production build. Review it on a branch, confirm the five image files exist at the listed paths, then run `npm run lint` and `npm run build` before deploying.
